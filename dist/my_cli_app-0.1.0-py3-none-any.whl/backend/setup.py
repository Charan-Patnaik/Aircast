from setuptools import setup, find_packages

setup(name='aircast-backend', version='1.0', packages=find_packages())