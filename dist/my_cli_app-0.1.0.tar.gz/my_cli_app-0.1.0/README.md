# Aircast

Rename sample.env to .env and change all the values accordingly.